import os

from flask import Flask

def create_app(test_config=None):
    """Create and configure an instance of the Flask application."""
    app = Flask(__name__, instance_relative_config=True)
    
    #설정 
    app.config.from_mapping(
        # a default secret that should be overridden by instance config
        SECRET_KEY="adslkfajewiofjnxvd",
        # store the database in the instance folder
        DATABASE=os.path.join(app.instance_path, "flaskr.sqlite"),
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile("config.py", silent=True)
    else:
        # load the test config if passed in
        app.config.update(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass


    #파일업로드 준비하기 
    # UPLOAD_FOLDER = r"C:\cloud_2023\final_project\flask_project_final\hello\static\upload"
    # MODEL_FOLDER = r"C:\cloud_2023\final_project\flask_project_final\hello\static\model"
    # app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER 
    # app.config['MODEL_FOLDER'] = MODEL_FOLDER 

    app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, "static/upload")
    app.config['MODEL_FOLDER'] = os.path.join(app.root_path, "static/model")
    
    #파일업로드 위치값을 config라는 dict타입에 위칟값 저장하기 
    # app.config["MAX_CONTENT_LENGTH"]= 20 * 1024 * 1024 #20MB까지만

    @app.route("/")
    def index():
        return "Hello !!"

    #블루프린트 
    from . import project 
    app.register_blueprint(project.bp) 



    # make url_for('index') == url_for('blog.index')
    # in another app, you might define a separate main index here with
    # app.route, while giving the blog blueprint a url_prefix, but for
    # the tutorial the blog will be the main index
    app.add_url_rule("/", endpoint="index")

    return app




"""
mysiteactivate
flask --app hello --debug run 

postman의 post 사용법
1) x-www-form-urlencoded
    <form method="post" ~~~ input 태그들의 값이 이 형식으로 서버로 보내진다
2) 파일 전송시
    <form method="post" enctype="multipart-form ~~
    form-data 형식으로 파일전송
3) json으로 보내고 싶을때
    raw 형식 --- json(postman 오른쪽 끝에 text->json)
    서버에서 어떤 형태로 정보를 수신할거냐에 따라서 보내는 방식이 달라져야 한다.

"""
