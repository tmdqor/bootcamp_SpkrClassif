from flask import Blueprint, flash, g, current_app  # current_app : app 가져다 쓰기
from flask import render_template, request, redirect
from . import CommonUtil 
import os
import librosa
import numpy as np
import pandas as pd
import tensorflow as tf
import math

#블루프린트 객체를 만든다. 블루프린트 객체를 통해서 __init__.py랑 연결된다. 
bp = Blueprint("project", __name__, url_prefix="/project")


@bp.route('/index', methods=['GET', 'POST'])
def list():
    uploads = current_app.config['UPLOAD_FOLDER']
    file_list = os.listdir(uploads)
    return render_template("project/index.html", data=file_list)

@bp.route('/save', methods=['POST'])
def save():
    file = request.files['upload']
    filename=""
    if file: # 파일 전송이 있을 때
        # filename1 = CommonUtil.getFilename(file.filename)
        filename = file.filename
        sfilename = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        file.save(sfilename)

        result_num, result_dict = deeplearning(filename)
        data = {"file_name":filename, "result_num":result_num, "result_dict":result_dict}
    return render_template("project/result.html", data=data)

@bp.route('/view/<filename>', methods=['GET', 'POST'])
def view(filename):
    results, result_names = deeplearning(filename)
    data = {"file_name":filename, "results":results, "result_name":result_names}
    return render_template("project/result.html", data=data)

# @bp.route('/test', methods=['GET', 'POST'])
# def test():
#     return render_template("project/test_img.html")

def deeplearning(filename):
    upload_path = current_app.config['UPLOAD_FOLDER']
    file_path = upload_path + "/" + filename

    # mfcc로 전환
    wav_X = make_mfcc(file_path)

    model_path = os.path.join(current_app.config['MODEL_FOLDER'], "model_cnn.h5")
    model = tf.keras.models.load_model(model_path)
    pred = model.predict(wav_X)

    labelset = {"유재석":0, "박명수":1, "정형돈":2, "노홍철":3, "하하":4, 
            "정준하":5, "유인나":6, "아이유":7, "김이나":8, "이수현":9}
    labelset_re = {v:k for k,v in labelset.items()}

    results = [np.argmax(value) for value in pred]
    result_names = [labelset_re[value] for value in results]

    return results, result_names

def make_mfcc(file_path):
    sample_rate = 16000
    y, sr = librosa.load(file_path, sr=sample_rate)
    print(y.shape, sr)

    time = y.shape[0] / sr
    print(time*2)

    mfccs_test = []
    for i in range(0, math.floor(time/0.5)):
        start = int(i*(sample_rate/2))
        end = int((i+1)*(sample_rate/2))
        features = librosa.feature.mfcc(y=y[start:end], 
                                                sr=sample_rate,
                                                n_mfcc=40, 
                                                hop_length=int(sample_rate*0.01),
                                                n_fft=int(sample_rate*0.02)).T
        mfccs_test.append(features)

    mfccs_test_np = np.array(mfccs_test)
    wav_X =  mfccs_test_np.reshape(-1, mfccs_test_np.shape[1], mfccs_test_np.shape[2], 1)

    return wav_X






